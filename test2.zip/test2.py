#!/usr/bin/python3
import time
import serial
import sqlite3
from threading import Thread
from system.OpenProtocol import OpenProtocol
from system.cmd_OpenProtocol import cmd_OpenProtocol
from model.SQLControler import sqlControler
import numpy as np
from lib.traySocket_v2 import TrayModbusV2

_socket_tray_enable = [
    False,False,False,False,False,False,False,False,
    False,False,False,False,False,False,False,False
    ]

_socket_tray_input = [
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0])
]

_socket_tray_led = [
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0]),
    list([0,0,0,0,0,0,0,0])
]
# socket_tray_led_prev = [
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
    
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
    
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
    
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0],
#     [0,0,0,0,0,0,0,0]
# ]

_socket_tray_led_color_pickup = 0xFFF
_socket_tray_led_color_picked = 0x0F0
_socket_tray_led_color_error = 0xF00
_socket_tray_led_color_return = 0x00F
_socket_tray_led_color_idle = 0xFF0

class ctl_core():
    def __init__(self, ip_address, port):
        super().__init__()
        self.ip_address = ip_address
        self.port = port
        self.tools_id = port - 9000
        
        self.tray_modbus = None
        
        # init
        self.res_vin_code = None
        
        # OpenProtocol
        self._open_cmd = cmd_OpenProtocol()
        self._open_pro = OpenProtocol(self.ip_address, self.port)
        
        
        # init_disable
        # self._open_pro.send_msg(self._open_cmd.Disable_tool())
        
        # self.thr_tool = Thread(target=self._tool_sys)
        # self.thr_tool.daemon = True
        # self.thr_tool.start()


    def _tool_sys(self):
        while True:
            self._open_pro.send_msg(self._open_cmd.Linking_Group_info_subscribe())
            # time.sleep(0.02)
            if self._open_pro.send_msg(self._open_cmd.Vehicle_Id_Number_upload_subscribe()) is True:
                self.res_vin_code = self._open_pro.Get_VIN_Number_CODE()
                if self.res_vin_code is None:
                    continue
            # time.sleep(1)
    def getLinking_Group_Info(self):
        if self._open_pro.send_msg(self._open_cmd.Linking_Group_info_subscribe()):
            return self._open_pro.getLinking_Group_Info()
        return None
    
    def getTools_ready(self):
        return self.tools_id, self.res_vin_code
    
    def setTools_ack(self):
        self._open_pro.Set_VIN_Number_CODE(None)
        # self.res_vin_code = None
        
    def getTool_link(self):
        return self._open_pro.getSelectLink()
   
    def last_tightening_result(self):
        self._open_pro.send_msg(self._open_cmd.Last_tightening_result_data_subscribe())
        return self._open_pro.GetData()
    
    def last_tight_none(self):
        self._open_pro.SetData(None)
        
    def disableTool(self):
        self._open_pro.send_msg(self._open_cmd.Disable_tool())
        
    def enableTool(self):
        self._open_pro.send_msg(self._open_cmd.Enable_tool())
                    
def IP_SQLtxt():
    SQLtxt = 'SELECT IP_Address FROM IP'
    return SQLtxt

def PORT_SQLtxt():
    SQLtxt = 'SELECT PORT_Tools FROM Tools'
    return SQLtxt    

def socket_link_SQLtxt(tool, link):
    SQLtxt = 'SELECT Socket_ID_Step FROM Step WHERE Step_Tools_ID = {} AND ID_Link_step = {} GROUP BY Socket_ID_Step'.format(tool, link)
    return SQLtxt

def step_link_SQLtxt(tool, link):
    SQLtxt = 'SELECT ID_TRAY_ID, Socket_ID_Step FROM Step WHERE Step_Tools_ID = {} AND ID_Link_step = {} ORDER BY Step_number ASC'.format(tool, link)
    return SQLtxt

def findTools(Tools):
    Tools_key = []
    for key, vin in Tools.items():
        if vin is not None:
            Tools_key.append(key)
    return Tools_key

# def thr_socket_step2(_tools_init, _tool, conn_db):
#     checked = 0
#     Linking_ID = _tool.getTool_link()['Linking_Group_ID']
#     res_socket_list = conn_db.db_QuerySQL(socket_link_SQLtxt(_tools_init, Linking_ID))
#     # res_socket_list is list socket not duplicate 
#     res_steps_socket = conn_db.db_QuerySQL(step_link_SQLtxt(_tools_init, Linking_ID))
#     _tool.last_tight_none()
#     while True:
#         print('Start Loop')
#         loop = len(res_steps_socket)
#         try:
#             res_steps_socket[checked][1]
#         except Exception as e:
#             break
    
#         if loop == checked:
#             checked = 0
#             print('exit loop')
#             break
        
#         # tray_modbus.pick_id((res_socket_list[checked][0])-1)
#         print(res_socket_list[checked][0]-1)
        
#         res_last_tigh = _tool.last_tightening_result()
        
#         # if tray_modbus.get_socket_ready():
#         #     _tool.enableTool()
#         # else:
#         #     _tool.disableTool()
            
#         if res_last_tigh is not None:
#             if int(res_last_tigh['Tightening_Status']):
#                 #_tool.disableTool()
#                 checked += 1
#                 print('Tightening :OK')
#             else:
#                 print('Tightening :NOK')
#                 if old_position != res_last_tigh['Batch_counter']:
#                     #_tool.disableTool()
#                     checked += 1
#                     # _tool.set_NextPosition()
#             old_position = res_last_tigh['Batch_counter']
#             _tool.last_tight_none()
#         time.sleep(0.01)
#     # tray_modbus.pick_id(-1)
#     print('end cycle position')
        
def thr_socket_step(_tools,conn_db):
    global _socket_tray_enable,_socket_tray_led,_socket_tray_input
    global _socket_tray_led_color_pickup,_socket_tray_led_color_picked
    global _socket_tray_led_color_error,_socket_tray_led_color_return,_socket_tray_led_color_idle
    
    linking_group_id = None
    linking_group_status = None
    linking_group_batch_mode = None
    linking_group_batch_size = None
    linking_group_batch_counter = None
    res_socket_list = None
    res_steps_socket = None
    socket_run_step = 0
    step_run_prev = -1
    while True:
        socket_tray_enable = _socket_tray_enable
        socket_tray_led = _socket_tray_led
        socket_tray_input = _socket_tray_input
        socket_tray_led_color_pickup = _socket_tray_led_color_pickup
        socket_tray_led_color_picked = _socket_tray_led_color_picked
        socket_tray_led_color_error = _socket_tray_led_color_error
        socket_tray_led_color_return = _socket_tray_led_color_return
        socket_tray_led_color_idle = _socket_tray_led_color_idle
    
        linking_group_data = _tools.getLinking_Group_Info()
        if linking_group_data is not None:
            tool_id = _tools.tools_id
            linking_group_id = int(linking_group_data['Linking_Group_ID'])
            linking_group_status = int(linking_group_data['Linking_Group_status'])
            linking_group_batch_mode = int(linking_group_data['Linking_Group_batch_mode'])
            linking_group_batch_size = int(linking_group_data['Linking_Group_batch_size'])
            linking_group_batch_counter = int(linking_group_data['Linking_Group_batch_counter'])
            
            print("tool_id=",tool_id , " ", linking_group_status ," ",linking_group_batch_size , " ", linking_group_batch_counter)
            res_steps_socket = conn_db.db_QuerySQL(step_link_SQLtxt(tool_id, linking_group_id))
            
            _tools.enableTool()
            
        if linking_group_status is not None and res_steps_socket is not None: 
                         
            if linking_group_status != 0: #Idle
                #Enable Socket to Uses
                
                for step in range(len(res_steps_socket)):
                    tray = res_steps_socket[step][0] - 1
                    socket = res_steps_socket[step][1] - 1
                    socket_tray_enable[tray] = True #Enable Tray
                    # print(" read = ",socket_tray_input[0])
                    if int(socket_tray_input[tray][socket]) >= 1: #Have Socket
                        socket_tray_led[tray][socket] = int(socket_tray_led_color_idle)
                        # print("-- ",socket_tray_led[tray][socket])
                        # print("idle ",tray," ",socket)
                    else:
                        socket_tray_led[tray][socket] = int(socket_tray_led_color_error)
                        # print("error ",tray," ",socket)

            if linking_group_status == 0: #Run Batch
                # print("linking_group_status=",linking_group_status) 
                # print("linking_group_batch_counter=",linking_group_batch_counter) 
                # print("linking_group_batch_size=",linking_group_batch_size) 
                if linking_group_batch_counter < linking_group_batch_size:
                    step_run = linking_group_batch_counter
                    if step_run != step_run_prev:
                        print("step_run=",step_run)
                        #Check All Socket Ready
                        all_socket_ready = True
                        for step in range(len(res_steps_socket)):
                            tray = res_steps_socket[step][0] - 1
                            socket = res_steps_socket[step][1] - 1
                            socket_tray_enable[tray] = True
                            if step == step_run_prev:
                                socket_tray_led[tray][socket] = int(socket_tray_led_color_return)
                            if int(socket_tray_input[tray][socket]) == 0:#No Socket
                                
                                all_socket_ready = False
                        # print("all_socket_ready=",all_socket_ready)        
                        if all_socket_ready is True:
                            step_run_prev = step_run
                            
                    if step_run == step_run_prev:#loop Pickup
                        for step in range(len(res_steps_socket)):#Set All Idle
                            tray = res_steps_socket[step][0] - 1
                            socket = res_steps_socket[step][1] - 1
                            socket_tray_enable[tray] = True
                            if step_run == step: #want to socket pickup
                                if socket_tray_input[tray][socket] >= 1:
                                    # print("pickup",socket+1 ," ", socket_tray_led[tray])
                                    socket_tray_led[tray][socket] = socket_tray_led_color_pickup
                                else:
                                    # print("picked",socket+1 ," ", socket_tray_led[tray])
                                    socket_tray_led[tray][socket] = socket_tray_led_color_picked
                            else:
                                socket_tray_led[tray][socket] = socket_tray_led_color_idle
                                
                    
            
            _socket_tray_enable = socket_tray_enable
            _socket_tray_led = socket_tray_led

                    # print("step=",step," ", res_steps_socket[step])
                    # pass
            
            # for step in range(len(res_steps_socket)):
            #     tray = res_steps_socket[step][0]
            #     socket = res_steps_socket[step][1]
            #     print("step = {} : tray = {} : socket = {}".format(step,tray,socket))
            # print("------------------")
        # tools_id, res_vin_code = _tools.getTools_ready()
        # _tools.setTools_ack()
        # if res_vin_code is not None: 
        #     Linking_ID = _tools.getTool_link()['Linking_Group_ID']
        #     res_socket_list = conn_db.db_QuerySQL(socket_link_SQLtxt(tools_id, Linking_ID))
        #     res_steps_socket = conn_db.db_QuerySQL(step_link_SQLtxt(tools_id, Linking_ID))
        #     _tools.last_tight_none()
        #     print("Tool {} : VIN = {} : LIK = {}".format(tools_id,res_vin_code,Linking_ID))
        #     # time.sleep(1)
        # else:
        #     print("none")
        time.sleep(0.5)
        
        
def main():
    global _socket_tray_enable,_socket_tray_led,_socket_tray_input
    global _socket_tray_led_color_pickup,_socket_tray_led_color_picked
    global _socket_tray_led_color_error,_socket_tray_led_color_return,_socket_tray_led_color_idle
    
    socket_tray_led_prev = [
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0]),
        list([0,0,0,0,0,0,0,0])
    ]
    
    # initialize variable
    _port_tools = []
    _tools_pool = []
    Tools = {}
    
    

    # initialize class
    conn_db = sqlControler(db_file='./database/openprotocol.db')
    
    # Query SQL
    _ip_address = conn_db.db_QuerySQL(IP_SQLtxt())[0][0]
    res_port = conn_db.db_QuerySQL(PORT_SQLtxt())
    for port in res_port:
        _tools_pool.append(ctl_core(
            ip_address=_ip_address,
            port=port[0]
            )
        )
        
        
    tray_modbus = TrayModbusV2(
        port='/dev/ttyUSB0', 
        device=0x01, 
        baudrate=9600, 
        bytesize = 8, 
        parity=serial.PARITY_NONE, 
        stopbits=1, 
        timeout=0.5
    )    
    # oparations
    thr_tools_pool = []
    for _tools in _tools_pool:
        thr_tools_pool.append(Thread(target=thr_socket_step, args=(_tools,conn_db,)))
                              
   
    # for i in range(8):
    #     thr_tools_pool[i].daemon = True
    #     thr_tools_pool[i].start()
    thr_tools_pool[3].daemon = True
    thr_tools_pool[3].start()
    
    

    while True:
        socket_tray_enable = _socket_tray_enable
        socket_tray_led = _socket_tray_led
        socket_tray_input = _socket_tray_input
        
        for tray in range(len(socket_tray_enable)):
            if socket_tray_enable[tray] is True:
                socket_tray_input[tray] = list(tray_modbus.readSocketTraySensor(tray))
                
                
                  
        for tray in range(len(socket_tray_enable)):   
            if socket_tray_enable[tray] is True:   
                print(tray," read = ",socket_tray_input[tray])
                print(tray," led = ",socket_tray_led[tray])  
                print(tray," prev = ",socket_tray_led_prev[tray])     
                if socket_tray_led_prev[tray] != socket_tray_led[tray]:
                    print(tray," write = ",socket_tray_led[tray])         
                    tray_modbus.writeSocketTrayLED(tray,list(socket_tray_led[tray]))
                    socket_tray_led_prev[tray] = socket_tray_led[tray]
         
                print(tray," prev2 = ",socket_tray_led_prev[tray])             
                    
        _socket_tray_input = socket_tray_input
        time.sleep(0.5)
        # print("tray = ",socket_tray_enable)      
        
        # tray_modbus.writeSocketTrayLED(0,[0xF00,0xF00,0xF00,0xF00,0xF00,0xF00,0xF00,0xF00])
        # time.sleep(0.25)
        # tray_modbus.writeSocketTrayLED(0,[0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000])
        # time.sleep(0.25)
        # if tools_init is not None:
        #     # print(tools_init)
        #     #_tools_pool[tools_init-1].set_tray_modbus(tray_modbus)
        #     _tools_pool[tools_init-1].setTools_ack()
        #     Linking_ID = _tools_pool[tools_init-1].getTool_link()['Linking_Group_ID']
        #     # print(res['Linking_Group_ID'])
        #     res_socket_list = conn_db.db_QuerySQL(socket_link_SQLtxt(tools_init, Linking_ID))
        #     # for socket in res_socket_list:
        #     #     tray_modbus.setEnable(int(socket[0])-1)
        #     res_steps_socket = conn_db.db_QuerySQL(step_link_SQLtxt(tools_init, Linking_ID))
        #     _tools_pool[tools_init-1].last_tight_none()
        #     while True:
        #         print('Start Loop')
        #         loop = len(res_steps_socket)
        #         try:
        #             res_steps_socket[checked][1]
        #         except Exception as e:
        #             break
            
        #         if loop == checked:
        #             checked = 0
        #             print('exit loop')
        #             break
                
        #         # tray_modbus.pick_id((res_socket_list[checked][0])-1)
        #         print(res_socket_list[checked][0]-1)
                
        #         res_last_tigh = _tools_pool[tools_init-1].last_tightening_result()
                
        #         # if tray_modbus.get_socket_ready():
        #         #     _tools_pool[tools_init-1].enableTool()
        #         # else:
        #         #     _tools_pool[tools_init-1].disableTool()
                    
        #         if res_last_tigh is not None:
        #             if int(res_last_tigh['Tightening_Status']):
        #                 #_tools_pool[tools_init-1].disableTool()
        #                 checked += 1
        #                 print('Tightening :OK')
        #             else:
        #                 print('Tightening :NOK')
        #                 if old_position != res_last_tigh['Batch_counter']:
        #                     #_tools_pool[tools_init-1].disableTool()
        #                     checked += 1
        #                     # _tools_pool[tools_init-1].set_NextPosition()
        #             old_position = res_last_tigh['Batch_counter']
        #             _tools_pool[tools_init-1].last_tight_none()
        #         time.sleep(0.01)
        #     # tray_modbus.pick_id(-1)
        #     print('end cycle position')
        # time.sleep(0.01)
    
if __name__=='__main__':
    main()
